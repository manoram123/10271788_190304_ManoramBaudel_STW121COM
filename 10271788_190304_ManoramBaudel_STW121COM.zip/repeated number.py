x= int(input('number of elements:'))
l=[]
for i in range(1,x+1):
    a=int(input('enter element:'))
    l.append(a)
print(l)
for a in range(0,len(l)-1):
    num=l[a]
    if l[a]==l[a+1]:
        print('duplicate',l[a],'found')




