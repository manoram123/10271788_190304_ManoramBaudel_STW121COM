m = int(input("Enter Mass in KG:"))
h = int(input("Enter Height in meter:"))
b   = m/((h)**2)
print("The Person's Body mass Index is:", b)


