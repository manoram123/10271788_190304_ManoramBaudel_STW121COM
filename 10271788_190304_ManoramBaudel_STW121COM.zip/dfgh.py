import turtle
p=turtle.Turtle()
p.circle(90,200)
p.right(120)
p.circle(90,200)
p.forward(180)
p.left(90)
p.forward(180)
turtle.done()