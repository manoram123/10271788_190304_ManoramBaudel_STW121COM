x= int(input("Enter Radius:"))
y= 3.1416*(x**2)
print("The Area Of Circle Is:",y)
