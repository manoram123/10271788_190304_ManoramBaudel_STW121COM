a= int(input("Enter A:"))
b= int(input("Enter B"))
c= int(input("Enter C"))
def max(a,b,c):
    if a>b and a>c:
        largest=a
    if b>a and b>c:
        largest =b
    else:
        largest= c
    return largest
