try:
    a= int(input('Enter a number:'))
    b= int(input('Enter a number:'))
    c=a/b
    print(c)
except BaseException as e:
    type(e)
    print('Error Information:',e)
    b=int(input('Enter correct value for b:'))
    print(a/b)


print('over')