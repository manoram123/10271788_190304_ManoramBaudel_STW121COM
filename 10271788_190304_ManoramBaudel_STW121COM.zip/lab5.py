a= int(input("Total no. of Students in A:"))
b= int(input("Total no. of Students in B:"))
c= int(input("Total no. of Students in C:"))
no_desk_a= (a//2)+(a%2)
no_desk_b= (b//2)+(b%2)
no_desk_c= (c//2)+(c%2)
total=no_desk_a+no_desk_b+no_desk_c
print (total)

