f= open('abc.txt','wb')
l=[1,2,3,4,5,6,7,8,9,10]
b= bytes(l)
f.write(b)
f.close()
f= open('abc.txt','rb')
d=f.read()
for i in d:
    print(int(i))

