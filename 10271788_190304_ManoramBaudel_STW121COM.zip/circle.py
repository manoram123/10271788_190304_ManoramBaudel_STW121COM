import turtle
wn=turtle.Screen()
pen=turtle.Turtle()
def function(r,x,y):
pen.circle(r)
turtle.done()