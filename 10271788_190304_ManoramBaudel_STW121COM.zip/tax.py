x= int(input("Enter your salary:"))
if x<= 400000:
    t= x*(1/100)
    print("Tax:",t)
elif x<=600000:
    t= (x-400000)*(5/100)+4000
    print("Tax",t)
elif x<=900000:
    t= (x-400000)*(5/100)+4000+(x-900000)*(15/100)
    print("Tax:",t)
elif x>900000:
    t= (x-400000)*(5/100)+400000*(1/100)+(x-900000)*(15/100)+
    print("")