x= int(input("Enter length:"))
y= int(input("Enter Breadth:"))
print("Area of Rectangle is:",x*y)