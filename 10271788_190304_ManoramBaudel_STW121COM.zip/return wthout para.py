def add(a,b):
    z= a+b
    return z
def subtract(a,b):
    z= a-b
    return z
def multiply(a,b):
    z= a*b
    return z
def division(a,b):
    z= a/b
    return z
a= int(input("A="))
b= int(input("B="))
x= int(input("1)Add 2)Subtract 3)Multiply 4)division"))
if x==1:
    ans= add(a,b)
    print("Sum=",ans)
elif x==2:
    ans= subtract(a,b)
    print("Subtract=",ans)
elif x==3:
    ans= multiply(a,b)
    print("Multiply=",ans)
elif x==4:
    ans= division(a,b)
    print("Division=",ans)
else:
    print("Invalid Option!")

