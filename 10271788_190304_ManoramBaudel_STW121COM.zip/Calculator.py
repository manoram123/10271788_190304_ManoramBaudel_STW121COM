def addition():
    a=int(input("Enter A:"))
    b=int(input("Enter B:"))
    c= a+b
    print("Sum is:",c)
def subtraction():
    a=int(input("Enter A:"))
    b=int(input("Enter B:"))
    c=a-b
    print("Subraction:",c)
def division():
    a= int(input("Enter A:"))
    b= int(input("Enter B:"))
    c=a/b
    print("Division:",c)
def multiplication():
    a = int(input("Enter A:"))
    b = int(input("Enter B:"))
    c = a * b
    print("Multiplication:", c)
x= int(input("1.Addition 2.Subtraction 3.Divioion 4.Multiplication"))
if x==1:
    addition()
elif x==2:
    subtraction()
elif x==3:
    division()
elif x==4:
    multiplication()




