lis=[]
x=int(input("Number of elements:"))
sum=0
a=1
while a<=x:
    i=int(input("Enter Element:"))
    sum=sum+i
    a=a+1
    lis.append(i)
print(lis)
print("Sum of the elements:",sum)

