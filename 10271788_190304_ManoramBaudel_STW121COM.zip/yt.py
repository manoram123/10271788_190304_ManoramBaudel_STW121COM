class manoram:
    def __init__(self,x,y):
        self.name=x
        self.roll=y
    def display(self):
        print("My Name is:",self.name)
        print("Roll Number:",self.roll)
obj=manoram('Manoram',1)
obj.display()