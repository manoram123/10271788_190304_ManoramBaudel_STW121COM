import strings
x=int(input('''1.Add
2.Subtract
3.Multiply
4.Division'''))
if x==1:
    strings.eadd()
if x == 1:
    strings.add()
if x==1:
    strings.add()