def add(a,b):
    z= a+b
    print("Sum=",z)
def subtract(a,b):
    z= a-b
    print("Subtract=",z)
def multiply(a,b):
    z= a*b
    print("Multiply=",z)
def division(a,b):
    z= a/b
    print("Division=",z)
a= int(input("A="))
b= int(input("B="))
x= int(input("1. Add 2.Subtract 3.Multiply 4.Division:"))
if x==1:
    add(a,b)
elif x==2:
    subtract(a,b)
elif x==3:
    multiply(a,b)
elif x==4:
    division(a,b)
