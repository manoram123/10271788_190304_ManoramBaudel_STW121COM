x=-1
for i in range(0,-5,-1)
    print(x)
    x=x-1
