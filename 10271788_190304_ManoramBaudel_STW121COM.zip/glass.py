import turtle
p= turtle.Turtle()
x= int(input('input'))
for i in range(0,x):
    a=input('control')
    if a=='A':
        p.left(90)
        p.forward(100)
turtle.done()
