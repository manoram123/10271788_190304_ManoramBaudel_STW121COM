x= int(input("Enter a number:"))

if x%2==0:
    print("This is Even Number!")
else:
    print("This is Odd Number!")
