x= int(input("Enter Base:"))
y= int(input("Enter Height:"))
a= (1/2)*(x*y)
print("Area of Triangle:", a)

