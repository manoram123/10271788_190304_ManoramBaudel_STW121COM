x=int(input("Enter numbers of elements:"))
i=1
while i<=x:
    a=int(input("enter element:"))
    print(a)
    i=i+1
