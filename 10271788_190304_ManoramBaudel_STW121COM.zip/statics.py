x=int(input('numbers of elements:'))
i=1
lis=[]
while i<=x:
    a=int(input('enter number:'))
    i=i+1
    lis.append(a)
print(lis)
lis.sort()
print('arringing elements in ascendng order',lis)
n= len(lis)
sum=0
for a in range(0,len(lis)):
    sum=sum+lis[a]
print('Mean:',sum/n)
m=int((n+1)/2)
median=lis[m-1]
print('Median:',median)

