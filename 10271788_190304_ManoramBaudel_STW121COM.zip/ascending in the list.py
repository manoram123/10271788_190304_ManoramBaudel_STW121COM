x=int(input("number of elements:"))
l=[]
for i in range(1,x+1):
    a=int(input("enter a number:"))
    l.append(a)
print(l)
k=0
while k<len(l):
    j=0
    while j<len(l)-1:
        if l[j]>l[j+1]:
            temp=l[j]
            l[j]=l[j+1]
            l[j+1]=temp
        j=j+1
    k=k+1
print(l)

